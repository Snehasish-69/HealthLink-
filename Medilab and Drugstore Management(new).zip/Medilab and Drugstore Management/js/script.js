// Simple Login Validation (Demo Only)
function validateLogin() {
  let user = document.getElementById("userid").value;
  let pass = document.getElementById("password").value;

  if (user === "admin" && pass === "admin123") {
    alert("Login Successful!");
    window.location.href = "dashboard.html"; // Redirect after login
    return false;
  }else if (user === "doctor" && pass === "doc123") {
    alert("Login Successful!");
    window.location.href = "doctor.html"; // Redirect after login
    return false;
  }
  else if (user === "lab" && pass === "ls123") {
    alert("Login Successful!");
    window.location.href = "reports.html"; // Redirect after login
    return false;
  }
  else if (user === "dispensary" && pass === "dis123") {
    alert("Login Successful!");
    window.location.href = "track.html"; // Redirect after login
    return false;
  } else {
    alert("Invalid User ID or Password!");
    return false;
  }
}

// Medicine search filter
function filterMedicines() {
  let input = document.getElementById("searchBox").value.toUpperCase();
  let table = document.getElementById("medicineTable");
  let tr = table.getElementsByTagName("tr");

  for (let i = 1; i < tr.length; i++) {
    let td = tr[i].getElementsByTagName("td")[1]; // Medicine Name column
    if (td) {
      let txtValue = td.textContent || td.innerText;
      tr[i].style.display = txtValue.toUpperCase().indexOf(input) > -1 ? "" : "none";
    }
  }
}

// Add medicine to stock table dynamically
document.addEventListener("DOMContentLoaded", function () {
  let form = document.getElementById("addMedicineForm");
  let table = document.getElementById("stockTable").getElementsByTagName("tbody")[0];

  form.addEventListener("submit", function (e) {
    e.preventDefault();

    let medID = document.getElementById("medID").value;
    let medName = document.getElementById("medName").value;
    let batchNo = document.getElementById("batchNo").value;
    let expiry = document.getElementById("expiry").value;
    let quantity = document.getElementById("quantity").value;

    let newRow = table.insertRow();
    newRow.innerHTML = `
      <td>${medID}</td>
      <td>${medName}</td>
      <td>${batchNo}</td>
      <td>${expiry}</td>
      <td>${quantity}</td>
    `;

    form.reset();
    alert("Medicine added successfully!");
  });
});

// Billing System
document.addEventListener("DOMContentLoaded", function () {
  let billingForm = document.getElementById("billingForm");
  let billTable = document.getElementById("billTable").getElementsByTagName("tbody")[0];
  let grandTotalElem = document.getElementById("grandTotal");
  let markPaidBtn = document.getElementById("markPaidBtn");

  let grandTotal = 0;

  billingForm.addEventListener("submit", function (e) {
    e.preventDefault();

    let billNo = document.getElementById("billNo").value;
    let patientID = document.getElementById("patientID").value;
    let medicineName = document.getElementById("medicineName").value;
    let quantity = parseInt(document.getElementById("quantity").value);
    let price = parseFloat(document.getElementById("price").value);

    let total = quantity * price;
    grandTotal += total;

    let newRow = billTable.insertRow();
    newRow.innerHTML = `
      <td>${billNo}</td>
      <td>${patientID}</td>
      <td>${medicineName}</td>
      <td>${quantity}</td>
      <td>₹${price.toFixed(2)}</td>
      <td>₹${total.toFixed(2)}</td>
    `;

    grandTotalElem.innerText = "Grand Total: ₹" + grandTotal.toFixed(2);

    billingForm.reset();
  });

  markPaidBtn.addEventListener("click", function () {
    if (grandTotal > 0) {
      alert("Payment successful! Total Paid: ₹" + grandTotal.toFixed(2));
      billTable.innerHTML = "";
      grandTotal = 0;
      grandTotalElem.innerText = "Grand Total: ₹0";
    } else {
      alert("No items to pay for.");
    }
  });
});

// Report Upload System (Demo Only)
document.addEventListener("DOMContentLoaded", function () {
  let uploadForm = document.getElementById("uploadReportForm");
  let reportsTable = document.getElementById("reportsTable").getElementsByTagName("tbody")[0];

  uploadForm.addEventListener("submit", function (e) {
    e.preventDefault();

    let reportID = document.getElementById("reportID").value;
    let patientID = document.getElementById("patientID").value;
    let fileInput = document.getElementById("reportFile");
    let fileName = fileInput.files[0].name;
    let today = new Date().toISOString().split("T")[0];

    let newRow = reportsTable.insertRow();
    newRow.innerHTML = `
      <td>${reportID}</td>
      <td>${patientID}</td>
      <td>${fileName}</td>
      <td>${today}</td>
      <td><a href="#">📄 Download</a></td>
    `;

    uploadForm.reset();
    alert("Report uploaded successfully!");
  });
});

// Contact Form Handler (Demo Only)
document.addEventListener("DOMContentLoaded", function () {
  let contactForm = document.getElementById("contactForm");
  if (contactForm) {
    contactForm.addEventListener("submit", function (e) {
      e.preventDefault();
      let name = document.getElementById("name").value;
      let email = document.getElementById("email").value;
      let message = document.getElementById("message").value;

      alert("Thank you, " + name + "! Your message has been sent.");
      contactForm.reset();
    });
  }
});

document.addEventListener('DOMContentLoaded', () => {
  const regTypeRadios = Array.from(document.getElementsByName('regType'));
  const testForm = document.getElementById('testForm');
  const treatmentForm = document.getElementById('treatmentForm');
  const successMessage = document.getElementById('successMessage');
  const patientsTableBody = document.querySelector("#patientsTable tbody");

  regTypeRadios.forEach(radio => {
    radio.addEventListener('change', () => {
      testForm.style.display = radio.value === 'test' ? 'flex' : 'none';
      treatmentForm.style.display = radio.value === 'treatment' ? 'flex' : 'none';
      successMessage.style.display = 'none';
    });
  });

  function savePatient(type, data) {
    const patients = JSON.parse(localStorage.getItem('patients')) || [];
    data.type = type;
    patients.push(data);
    localStorage.setItem('patients', JSON.stringify(patients));
    renderPatients();
  }

  function renderPatients() {
    const patients = JSON.parse(localStorage.getItem('patients')) || [];
    patientsTableBody.innerHTML = "";

    patients.forEach((patient, index) => {
      const row = patientsTableBody.insertRow();
      row.insertCell(0).innerText = index + 1;
      row.insertCell(1).innerText = patient.name || 'N/A';
      row.insertCell(2).innerText = patient.email || 'N/A';
      row.insertCell(3).innerText = patient.phone || 'N/A';
      row.insertCell(4).innerText = patient.type || 'N/A';
      const details = patient.type === "test" ? patient.testType : patient.symptoms;
      row.insertCell(5).innerText = details || 'N/A';
    });
  }

  testForm.addEventListener('submit', (e) => {
    e.preventDefault();

    const name = document.getElementById('testName').value.trim();
    const email = document.getElementById('testEmail').value.trim();
    const phone = document.getElementById('testPhone').value.trim();
    const testType = document.getElementById('testType').value;

    savePatient('test', { name, email, phone, testType });

    successMessage.innerText = `✅ ${name} successfully registered for ${testType}!`;
    successMessage.style.display = 'block';
    testForm.reset();
  });

  treatmentForm.addEventListener('submit', (e) => {
    e.preventDefault();

    const name = document.getElementById('treatName').value.trim();
    const email = document.getElementById('treatEmail').value.trim();
    const phone = document.getElementById('treatPhone').value.trim();
    const symptoms = document.getElementById('symptoms').value.trim();

    savePatient('treatment', { name, email, phone, symptoms });

    successMessage.innerText = `✅ ${name} successfully registered for treatment!`;
    successMessage.style.display = 'block';
    treatmentForm.reset();
  });

  renderPatients();
});
document.addEventListener('DOMContentLoaded', () => {
  const addMedicineForm = document.getElementById('addMedicineForm');
  const stockTableBody = document.querySelector('#stockTable tbody');
  const stockSuccessMsg = document.getElementById('stockSuccessMessage');

  function saveMedicine(data) {
    const stock = JSON.parse(localStorage.getItem('stock')) || [];
    
    const exists = stock.some(item => item.medID === data.medID);
    if (exists) {
      alert('Medicine ID already exists in stock!');
      return;
    }

    stock.push(data);
    localStorage.setItem('stock', JSON.stringify(stock));
    renderStock();

    stockSuccessMsg.innerText = `✅ Medicine "${data.medName}" added successfully!`;
    stockSuccessMsg.style.display = 'block';
    setTimeout(() => stockSuccessMsg.style.display = 'none', 3000);
  }

  function renderStock() {
    const stock = JSON.parse(localStorage.getItem('stock')) || [];
    stockTableBody.innerHTML = '';

    stock.forEach((item, index) => {
      const row = stockTableBody.insertRow();
      row.insertCell(0).innerText = item.medID;
      row.insertCell(1).innerText = item.medName;
      row.insertCell(2).innerText = item.batchNo;
      row.insertCell(3).innerText = item.expiry;
      row.insertCell(4).innerText = item.quantity;

      const actionCell = row.insertCell(5);
      const deleteBtn = document.createElement('button');
      deleteBtn.textContent = '🗑 Delete';
      deleteBtn.className = 'delete-btn';
      deleteBtn.addEventListener('click', () => {
        stock.splice(index, 1);
        localStorage.setItem('stock', JSON.stringify(stock));
        renderStock();
      });
      actionCell.appendChild(deleteBtn);
    });
  }

  addMedicineForm.addEventListener('submit', (e) => {
    e.preventDefault();

    const medID = document.getElementById('medID').value.trim();
    const medName = document.getElementById('medName').value.trim();
    const batchNo = document.getElementById('batchNo').value.trim();
    const expiry = document.getElementById('expiry').value;
    const quantity = document.getElementById('quantity').value;

    saveMedicine({ medID, medName, batchNo, expiry, quantity });
    addMedicineForm.reset();
  });

  renderStock();
});

// Render reports table from localStorage
function renderReports() {
  const reports = JSON.parse(localStorage.getItem('reports')) || [];
  const reportsTableBody = document.querySelector("#reportsTable tbody");
  if (!reportsTableBody) return;
  reportsTableBody.innerHTML = "";

  if (reports.length === 0) {
    // Optionally show a message if no reports
    const row = reportsTableBody.insertRow();
    const cell = row.insertCell(0);
    cell.colSpan = 5;
    cell.innerText = "No reports available.";
    cell.style.textAlign = "center";
    return;
  }

  reports.forEach(report => {
    const row = reportsTableBody.insertRow();
    row.insertCell(0).innerText = report.reportID || 'N/A';
    row.insertCell(1).innerText = report.patientID || 'N/A';
    row.insertCell(2).innerText = report.fileName || 'N/A';
    row.insertCell(3).innerText = report.date || 'N/A';
    row.insertCell(4).innerHTML = `<a href="#">📄 Download</a>`;
  });
}

document.addEventListener('DOMContentLoaded', renderReports);
localStorage.setItem('reports', JSON.stringify([
  {reportID: "R101", patientID: "P001", fileName: "Blood Test Report", date: "2025-09-10"},
  {reportID: "R102", patientID: "P002", fileName: "X-Ray Report", date: "2025-09-05"}
]));

    function logout() {
      if (confirm("Are you sure you want to log out?")) {
        // Optional: clear session/local storage
        // localStorage.clear();
        // sessionStorage.clear();
        window.location.href = "login.html";
      }
    }

